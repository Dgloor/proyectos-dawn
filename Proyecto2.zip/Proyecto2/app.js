async function getToken() {
  const clientId = "2ecf9281367b4c15906462c6549d1ccf";
  const clientSecret = "f12f8460ddca4e0bb52e0e8d9d99509c";
  const tokenURL = "https://accounts.spotify.com/api/token";

  try {
    const response = await fetch(tokenURL, {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        Authorization: "Basic " + btoa(clientId + ":" + clientSecret),
      },
      body: "grant_type=client_credentials",
    });

    const data = await response.json();
    return data.access_token;
  } catch (error) {
    console.log(error);
    return null;
  }
}

async function loadData() {
  const container = document.querySelector(".tracks");

  const token = await getToken();

  const tracksEndPoint =
    "https://api.spotify.com/v1/tracks?ids=4iV5W9uYEdYUVa79Axb7Rh,1301WleyT98MSxVHPZCA6M";

  const response = await fetch(`${tracksEndPoint}`, {
    method: "GET",
    headers: { Authorization: "Bearer " + token },
  });

  const data = await response.json();
  const tracks = data["tracks"];

  tracks.forEach((track) => {
    const name = track["name"];

    container.innerHTML += `
    <li class="track">
    ${name}
    </li>`;
  });
}

window.addEventListener("DOMContentLoaded", () => {
  loadData();
});
